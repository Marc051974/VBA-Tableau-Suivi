# Projet Excel VBA – Suivi Commercial

Ce dépôt contient les macros VBA pour automatiser le suivi des propositions commerciales.